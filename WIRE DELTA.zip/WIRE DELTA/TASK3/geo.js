function calcCircumfrence() {
   var diameter = prompt("please enter a number") ;
  var cir = Math.PI*diameter 
  document.getElementById("CircumferenceOutput").innerHTML = "The circumference is "+ cir + "." 
}
function calcArea() {
  var radius = prompt("please enter a number");
  var area = Math.PI*Math.pow(radius,2);
  document.getElementById("AreaOutput").innerHTML = "This is the area "+ area + " ."
}
// All functions below this point are practice and not unnecessary// 
function diameterFinder(){
  var radius = prompt("enter a number");
  var diameter = 2*radius;
  document.getElementById("Diameter").innerHTML = "This is your diameter: " + diameter + "."}
function calcCircumfrenceRadius() {
  var radius = prompt("enter a number");
  var cir = 2*Math.PI*radius;
  document.getElementById("Circumfrence").innerHTML = "This is the Circumfrence (found using the Raidus):" + cir + ".";
  
} // not printing, look into. 

